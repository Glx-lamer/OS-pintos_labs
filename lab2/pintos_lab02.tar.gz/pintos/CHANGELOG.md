# Changelog

All notable changes to this project will be documented in this file.

## 2021-07-16

### Added 

- Build and publish [container image](https://hub.docker.com/r/liangroy/pintos_dev_container) to Docker Hub, so that no need to rebuild image every time. 
- Add sample debug configs for Project 2 and 3 for references.

### Changed

- Update debug guide and documentation in README